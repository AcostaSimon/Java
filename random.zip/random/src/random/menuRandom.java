package random;

import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.lang.Math;



/**
 *
 * @author Simon Acosta
 */
public class menuRandom extends javax.swing.JFrame {
    
    /*  Iconos/Imagenes: */
    Icon lista;
    Icon agregar;
    Icon pregunta;
    Icon ayuda;
    
    /*  Variables globales: */
    List<String> ejemploLista = new ArrayList<>();
    List<String> verificado = new ArrayList<>();
    String sumaCaracteres = "";           // String            ->
    public List<String> AlmacenadorListas(){
     /*
        - Funcion:
        El funcionamiento consiste en el dise�o de un tipo de lista para valores numericos. Para el ingreso de datos se utilizo un
        bucle de repeticion indefinida, loopWhile. Dentro del mismo se encuentran las intrucciones que nos muestran en pantalla las
        funciones de ingreso de datos por teclado. Podremos ingresar datos numericos siempre y cuando la condicion de finalizar el
        programa no se active. Al activase la condicion la funcion finaliza y nos entrega la lista con los datos ingresados previamente.
        - AlmacenadorEnListas:
        void -> ArrayList(STRING)																							  */

        //List<String> ejemploLista; // Dise�o de lista con cadena de caracteres -> String.
        //ejemploLista = new ArrayList<>();

        
        int var1 = JOptionPane.showConfirmDialog(null, "Desea almacenar un dato?", "Confirmar: ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,agregar);

        while (var1 == JOptionPane.YES_OPTION) { // Bucle de repeticion indefinida, While.
            
            if (var1 == JOptionPane.NO_OPTION) { // Condicional: Al finalizar la entrada de datos, se informara y se entregara la lista final.
                JOptionPane.showMessageDialog(null, "Entrada de datos finalizada."); // Muesta en pantalla mensaje de salida.
                return ejemploLista; // Retorna un ArrayList, cuyo contenido es en String con N elementos.
            } // Cierre de if.

            if (var1 == JOptionPane.YES_OPTION) {
                String sueldo = JOptionPane.showInputDialog("Por favor, ingrese el dato que desea incluir: ");
                ejemploLista.add(sueldo); // Agregar un numero flotante a la lista.
            }
            var1 = JOptionPane.showConfirmDialog(null, "Quiere seguir ingresando datos?", "Confirmar: ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,agregar);
        }//Cierre de loopWhile.
        return ejemploLista; // Retorna un ArrayList, cuyo contenido es en String con N elementos.
    } // Fin de Almacenador en Listas.
    
    public String Desordenar(){
            /*  Declaracion de variables: */
        int cantidad = ejemploLista.size(); // ArrayList<String> -> Number(Int)
        int azar;                             // Number(Int)       -> Number(Int)
        String ejemplo;                       // String            ->
        String EnteroCadena;
        boolean existeDentro;
        
        /*  Condicionales: */
        if (cantidad<=0){ // Cantidad de elementos en listas iguales a cero.
            JOptionPane.showMessageDialog(null,"No existen valores ingresados.");
        } // Cierre de if.
        
        else{ // Caso contrario.
            /*  Bucle de repeticion definida: */
            for(int i=0;i<cantidad;i++){ // Reorganizar elementos. [MODIFICAR -]
            
                /*  Generar un numero entero aleatorio entre N y cero. */
                azar = (int) (Math.random()*cantidad*1);      // Number(Int)          -> Number(Int)
            
                /*  Almacenar datos usados: */
                EnteroCadena = Integer.toString(azar);
                existeDentro = verificado.contains(EnteroCadena);
                
                /*  Condicionales: */
                if (existeDentro!=true){
                    verificado.add(EnteroCadena);
                    /*  Lista azar: */
                    ejemplo = ejemploLista.get(azar);             // Number(Int)          -> String
                    sumaCaracteres = sumaCaracteres+"\n"+ejemplo; // String String String -> String
                } // Cierre de if.
                if (existeDentro==true){
                        i=i-1;
                } // Cierre de if.
            }// Fin de loopFor.
        } // Cierre de else.
        return "\n"+sumaCaracteres;
   } // Fin de Desordenar.
    
    public void datos(){ 
        List<String> AlmacenadorListas = AlmacenadorListas(); // ArrayList ->
        Desordenar();
    }

    public menuRandom() {
        initComponents();
        lista = new ImageIcon("src/Imagenes/lista.png");
        agregar = new ImageIcon("src/Imagenes/agregar.png");
        pregunta = new ImageIcon("src/Imagenes/pregunta.png");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JDesktopPane();
        popupMenu1 = new java.awt.PopupMenu();
        jPanel1 = new javax.swing.JPanel();
        Ingresar = new javax.swing.JButton();
        Resultados = new javax.swing.JButton();
        Random = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        utilidad = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        javax.swing.GroupLayout FondoLayout = new javax.swing.GroupLayout(Fondo);
        Fondo.setLayout(FondoLayout);
        FondoLayout.setHorizontalGroup(
            FondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FondoLayout.setVerticalGroup(
            FondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        popupMenu1.setLabel("popupMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(26, 28, 30));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.darkGray, null, null));
        jPanel1.setForeground(new java.awt.Color(139, 0, 0));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);
        jPanel1.setFocusCycleRoot(true);
        jPanel1.setFocusable(false);
        jPanel1.setFont(new java.awt.Font("Parchment", 0, 36)); // NOI18N
        jPanel1.setName(""); // NOI18N

        Ingresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/agregar.png"))); // NOI18N
        Ingresar.setText("Agregar");
        Ingresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarActionPerformed(evt);
            }
        });

        Resultados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/lista.png"))); // NOI18N
        Resultados.setText("Cantidad");
        Resultados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Resultados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResultadosActionPerformed(evt);
            }
        });

        Random.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/pregunta.png"))); // NOI18N
        Random.setText("Aleatorio");
        Random.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Random.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RandomActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Blacksword", 0, 70)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(240, 240, 240));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Aleatorio!");

        utilidad.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ayuda.png"))); // NOI18N
        utilidad.setText("Funcion");
        utilidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                utilidadActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/notas.png"))); // NOI18N
        jButton1.setText(" Notas");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Ingresar, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Resultados)
                        .addGap(18, 18, 18)
                        .addComponent(Random))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(utilidad, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(utilidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Ingresar)
                    .addComponent(Resultados)
                    .addComponent(Random))
                .addGap(10, 10, 10))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RandomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RandomActionPerformed
        /*  Ventana de notificacion: */
        JOptionPane.showMessageDialog(null,"Elementos mezclados:\n"+sumaCaracteres); // String String -> None
    }//GEN-LAST:event_RandomActionPerformed

    private void ResultadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResultadosActionPerformed
        
        /*  Declaracion de variables: */
        int cantidad = ejemploLista.size(); // Number ->
        String elemento; // String ->
        String sumaCadena = ""; // String ->
        
        /*  Condicionales: */
        if (cantidad==0){ // Cantidad de elementos en listas iguales a cero.
            JOptionPane.showMessageDialog(null,"No existen valores ingresados.");
        } // Cierre de if.
        if (cantidad!=0){ // Cantidad de elementos en listas iguales a cero.
            /*  Ciclo de repeticion definida: */
            for (int i=0;i<cantidad;i++){ // Iterar dentro del ArrayList.
                elemento = ejemploLista.get(i); // Extraer el elemento que concuerde con la iteracion.
                sumaCadena=sumaCadena+"\n"+elemento; // Generar un String con los elementos del ArrayList.
            } // Fin de loopFor.

            /*  Mostrar en pantalla: */
            JOptionPane.showMessageDialog(rootPane, "Los datos ingresados fueron:\n"+sumaCadena+"\n");
        }

    }//GEN-LAST:event_ResultadosActionPerformed

    private void IngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarActionPerformed
        datos();
    }//GEN-LAST:event_IngresarActionPerformed

    private void utilidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_utilidadActionPerformed
	String ms1 = "Mi funcion es entregar un resultado usando la aleatoriedad como formula.\n";
	String ms2 = "Una vez entregados todos los datos comenzare con el \"sorteo\", en donde seleccionare\n";
	String ms3 = "datos al azar y mostrare una lista mezclada con todos esos datos restantes.\n";
        JOptionPane.showMessageDialog(rootPane, ms1+ms2+ms3);
    }//GEN-LAST:event_utilidadActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String ms0 = "- Bug en la funcion Desordenar:\n";
        String ms1 = "Al volver a invocarla el programa entra en posible bucle infinito. Funcion anexada al boton agregar.\n\n";
        String ms2 = "\n\nv2.5.A.S.091018";
        JOptionPane.showMessageDialog(rootPane, ms0+ms1+ms2);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menuRandom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menuRandom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menuRandom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menuRandom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuRandom().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JDesktopPane Fondo;
    public static javax.swing.JButton Ingresar;
    public static javax.swing.JButton Random;
    public static javax.swing.JButton Resultados;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    public static javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private java.awt.PopupMenu popupMenu1;
    private javax.swing.JButton utilidad;
    // End of variables declaration//GEN-END:variables
}
